package serverResponse

var ResponseProcessGraph string
